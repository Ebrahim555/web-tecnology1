<html>
<body>
<?php
$err='';
$username = $password ="";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = test_input($_POST["username"]);
$password = test_input($_POST["password"]);
if(empty($Username) && empty($password)){
$err='fill up fielf';}
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<h2>PHP Form Validation Example</h2>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
Username: <input type="text" name="username"><?php echo $err ?><br>
Password: <input type="text" name="password"><?php echo $err ?><br>
<input type="submit" name="login" value="Login">
 <input type="checkbox"name="remember Me"value="Remember Me">
 <a href="forgetpassword.php">forgetpassword</a>
</form>


<?php
echo "<h2>Your Input:</h2>";
echo $username;
echo "<br>";
echo $password;
?>

</body>
</html>