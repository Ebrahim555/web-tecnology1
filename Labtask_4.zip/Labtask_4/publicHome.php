<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Public Home</title>
</head>
<body>
	<table border="1" width="50%">
		<tr height="70">
			<td align="right">
				<img src="company.png" align="left" width="100" height="70">
			    <a  href="Homepage.php">Homepage</a>
			    <a href="login.php">Login</a>&nbsp|
			    <a  href="registration.php">Registration</a>
			</td>
		</tr>
		<tr height="200">
			<td><h1>Welcome to our company</h1></td>
			
		</tr>
		<tr height="40">
			
			<td align="center">
				<h3>Copyright @2017</h3>
			</td>
		</tr>
		
	</table>
</body>
</html>