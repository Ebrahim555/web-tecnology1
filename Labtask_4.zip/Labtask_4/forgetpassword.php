<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Forgot Password</title>
</head>
<body>
	<table border="1" width="50%">
		<tr height="70">
			<td align="right">
				<img src="company.png" align="left" width="100" height="70">
			    <a href="">Home</a>&nbsp|
			    <a href="login.php">Login</a>&nbsp|
			    <a  href="registration.php">Registration</a>
			</td>
		</tr>
		<tr height="200">
			<td>
             <form method="POST" action="">
             	<fieldset>
             		<legend>FORGOT PASSWORD</legend>
             	
             		<h4>Enter Email :<input type="email" name="email" value=""></h4><hr>
             		<h4> Enter Otp number:<input type="taxt" name="number" value=""></h4><hr>
					<input type="submit" name="submit" value="Submit">
				
             	</fieldset>
             </form>
			</td>
			
		</tr>
		<tr height="40">
			
			<td align="center">
				<h3>Copyright @2017</h3>
			</td>
		</tr>
		
	</table>
</body>
</html>