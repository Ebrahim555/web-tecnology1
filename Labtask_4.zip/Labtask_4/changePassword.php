<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Change Password</title>
</head>
<body>
	<table border="1" width="50%">
		<tr height="70">
			<td colspan="2" align="right">
				<img src="company.png" align="left" width="100" height="70">
				<h4>Logged in as
				<a href="">Bob</a>&nbsp|
			    <a href="login.php">Logout</a>|</h4>
			    
			   
			</td>
		</tr>
		<tr height="250">
			<td width="280px"><h3>Account</h3><hr>
				<ul>
					<li><a href="dashboard.php">Dashboard</a></li>
					<li><a href="viewProfile.php">View Profile</a></li>
					<li><a href="editProfile.php">Edit Profile</a></li>
					<li><a href="profilePicture.php">Change Profile Picture</a></li>
					<li><a href="changePassword.php">Change Password</a></li>
					<li><a href="publicHome.php">Logout</a></li>
				</ul>
			</td>
			<td>
				<?php



  $current_password_err = $new_password_err = $retyped_password_err = "";
// Validation 
$currPass = "ebrahim12";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_password = $_POST["current_password"];
    $new_password = $_POST["new_password"];
    $retyped_password = $_POST["retyped_password"];

    $current_password_err = $new_password_err = $retyped_password_err = "";

    // Validate current password
    if ($current_password !== $currPass) {
        $current_password_err = "Invalid current password.";
    }

    // Validate new password
    if ($new_password === $currPass) {
        $new_password_err = "New password should not be same  current password.";
    }

    // Validate retyped password
    if ($retyped_password !== $new_password) {
        $retyped_password_err = "Retyped password must match with  new password.";
    }

    //  update password
    if (empty($current_password_err) && empty($new_password_err) && empty($retyped_password_err)) {
        // Code to update password goes here
       echo "Password updated ";
    }
}

?>

	  
<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
	<label for="current_password">Current Password:</label>
		<input type="text" id="current_password" name="current_password" required><?php echo $current_password_err; ?><br>
<br><br>
		<label for="new_password">New Password:</label>
	<input type="password" id="new_password" name="new_password" required><?php echo $new_password_err; ?><br>
<br><br>
		<label for="retyped_password">Retype Password:</label>
	<input type="password" id="retyped_password" name="retyped_password" required><?php echo $retyped_password_err; ?><br>
<br><br>
<input type="checkbox"name="remember Me"value="Remember Me">
		<input type="submit" value="Submit">
	</form>
			</td>
			
		</tr>
		<tr height="40">
			
			<td colspan="2" align="center">
				<h3>Copyright @2017</h3>
			</td>
		</tr>
		
	</table>
</body>
</html>