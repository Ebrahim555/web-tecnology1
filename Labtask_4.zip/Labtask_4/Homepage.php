<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dash Board</title>
</head>
<body>
	<table border="1" width="50%">
		<tr height="70">
			<td colspan="2" align="right">
				<img src="company.png" align="left" width="100" height="70">
				<h1>Welcome to our website</h1>
			    
			   
			</td>
		</tr>
		<tr height="200">
			<td width="300px"><h3>Account</h3><hr>
				<ul>
					<li><a href="login.php">Login here</a></li>
					<li><a href="registration.php">sign up here</a></li>
				</ul>
			</td>
			<td><h2>Welcome Bob</h2></td>
			
		</tr>
		<tr height="40">
			
			<td colspan="2" align="center">
				<h3>Copyright @2017</h3>
			</td>
		</tr>
		
	</table>
</body>
</html>