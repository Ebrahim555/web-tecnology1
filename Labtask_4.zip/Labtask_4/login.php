<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
</head>
<body>
	<table border="1" width="50%">
		<tr height="70">
			<td align="right">
				<img src="company.png" align="left" width="100" height="70">
			   <a  href="Homepage.php">Homepage</a>
			    
			    <a  href="registration.php">Registration</a>
			</td>
		</tr>
		<tr height="100px">
			<td>
    <?php
$err='';
$username = $password ="";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = test_input($_POST["username"]);
$password = test_input($_POST["password"]);
if(empty($Username) && empty($password)){
$err='fill up fielf';}
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<h2>Welcome to our website</h2>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
Username: <input type="text" name="username"><?php echo $err ?><br>
Password: <input type="text" name="password"><?php echo $err ?><br>
<input type="submit" name="login" value="Login">
 <input type="checkbox"name="remember Me"value="Remember Me">
 <a href="forgetpassword.php">forgetpassword</a>
</form>


     
			</td>
			
		</tr>
		<tr height="40">
			
			<td align="center">
				<h3>Copyright @2017</h3>
			</td>
		</tr>
		
	</table>
</body>
</html>