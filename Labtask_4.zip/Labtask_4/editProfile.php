<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Edit Profile</title>
</head>
<body>
	<table border="1" width="50%">
		<tr height="70">
			<td colspan="2" align="right">
				<img src="company.png" align="left" width="100" height="70">
				<h4>Logged in as
				<a href="">Bob</a>&nbsp|
			    <a href="login.php">Logout</a>|</h4>
			    
			   
			</td>
		</tr>
		<tr height="200">
			<td width="300px"><h3>Account</h3><hr>
				<ul>
					<li><a href="dashboard.php">Dashboard</a></li>
					<li><a href="viewProfile.php">View Profile</a></li>
					<li><a href="editProfile.php">Edit Profile</a></li>
					<li><a href="profilePicture.php">Change Profile Picture</a></li>
					<li><a href="changePassword.php">Change Password</a></li>
					<li><a href="publicHome.php">Logout</a></li>
				</ul>
			</td>
			<td>
			
			
	<?php
$err='';
$err1='';

$name = $email = $gender =  $day= $month= $year= $blood="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = test_input($_POST["name"]);
  $email = test_input($_POST["email"]);
  
 
  $gender = test_input($_POST["gender"]);
   $day = test_input($_POST["day"]);
    $month = test_input($_POST["month"]);
	 $year = test_input($_POST["year"]);
	  $blood = test_input($_POST["blood"]);
 
}


if(empty($name) && empty($email)){
$err='fill up fielf';}

if(empty($name) && empty($email)){
$err1='chose one fielf';}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<h2>fill up your information </h2>
	<fieldset>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Name: <input type="text" name="name"><?php echo $err ?> <br><br>
  E-mail: <input type="text" name="email"><?php echo $err ?><br><br>
 
  
  Gender:
  <input type="radio" name="gender" value="Female">Female
  <input type="radio" name="gender" value="Male">Male
  <input type="radio" name="gender" value="other">Other
  <?php echo $err1 ?>
  <br><br>
  
 

 <h4>Date Of Birth :<input type="date" name="date" value=""></h4><hr>
  
 Blood:
  
  <select id="blood" name="blood" required>  
        <option value="A+" name="blood">A+</option>
        <option value="A-" name="a-">A-</option>
        <option value="B+" name="b+">B+</option>
        <option value="B-" name="b-">B-</option>
		<option value="B+" name="b+">O+</option>
        <option value="B-" name="b-">O-</option>
        <option value="AB+" name="ab+">AB+</option>
        <option value="AB-" name="ab-">AB-</option>
    </select>
  <br><br>
  
  <input type="checkbox"name="remember Me"value="Remember Me">
 

		
<input type="submit" name="submit" value="Submit">
				
             	</fieldset>
             </form>
			</td>
			
		</tr>
		<tr height="40">
			
			<td colspan="2" align="center">
				<h3>Copyright @2017</h3>
			</td>
		</tr>
		
	</table>
</body>
</html>